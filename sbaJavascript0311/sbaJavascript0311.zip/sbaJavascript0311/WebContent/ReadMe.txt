ReadMe File

Zumba With Theresa is a website for users, especially members of Theresa's zumba classes, to get more information regarding the classes.  Users can come here to purchase videos, music, or live classes.  The Website is informative, but also offers an ecommerce component.

The website uses jQuery for the drop down menus.  Is use mouseevents for the mouseovers on the media product pages.

There is css form validation.

There is a sassy file with one style which is referenced by the contact page