

                   // var arrayVendors= [];
                     //   for(i=0;i<=10;i++){
                     //       arrayVendors[i] = "BNY Vendor" + i;
                     //   }

                  //  console.log(arrayVendors);
                  //  console.log(arrayVendors.length);

                        $(document).ready(function(){//document.ready is when the load of the page

                     
                     //Home
                     /*
                      var menuItemHome = ["Sales","Gifts"];
                      
                      
                        for (var i in menuItemHome){
                        menuItemHome[i];
                            
                        console.log(menuItemHome[i]);
                        
                        
                            $("#menuHome").append("<a href=\"#\" style=\"color:black;\">" +  menuItemHome[i] + "</a>");
                             //console.log("<a href=\"#\" style=\"color:black;\">" +  menuItemHome[i] + "</a>") ;  
                        }*/

                        //Products
                        var menuItemProduct = ["Video","Music","Class"];
                         for (var i in menuItemProduct){
                        menuItemProduct[i];
                            
                        console.log(menuItemProduct[i]);
                        
                        
                            $("#menuProducts").append("<a href=\"#\" style=\"color:black;\">" +  menuItemProduct[i] + "</a>");
                             //console.log("<a href=\"#\" style=\"color:black;\">" +  menuItemProduct[i] + "</a>") ;  
                        }

                         //Schedule
                        var menuSchedule = ["Classes","Events"];
                         for (var i in menuSchedule){
                        menuSchedule[i];
                            
                        console.log(menuSchedule[i]);
                        
                        
                            $("#menuSchedule").append("<a href=\"#\" style=\"color:black;\">" +  menuSchedule[i] + "</a>");
                             //console.log("<a href=\"#\" style=\"color:black;\">" +  menuSchedule[i] + "</a>") ;  
                        }

                        //About
                        var menuAbout = ["Mission","My Story","Testimonials"];
                         for (var i in menuAbout){
                        menuAbout[i];
                            
                        console.log(menuAbout[i]);
                        
                        
                            $("#menuAbout").append("<a href=\"#\" style=\"color:black;\">" +  menuAbout[i] + "</a>");
                             //console.log("<a href=\"#\" style=\"color:black;\">" +  menuAbout[i] + "</a>") ;  
                        }

                        //Contact
                        var menuContact = ["Email"];
                         for (var i in menuContact){
                        menuContact[i];
                            
                        console.log(menuContact[i]);
                        
                        
                            $("#menuContact").append("<a href=\"#\" style=\"color:black;\">" +  menuContact[i] + "</a>");
                             //console.log("<a href=\"#\" style=\"color:black;\">" +  menuContact[i] + "</a>") ;  
                        }



                    });
                
                   
                    